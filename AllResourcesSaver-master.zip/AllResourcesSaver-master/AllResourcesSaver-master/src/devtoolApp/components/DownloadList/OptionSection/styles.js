import styled from 'styled-components';

export const OptionSectionWrapper = styled.div`
  padding: 0 20px 20px 20px;
`;
